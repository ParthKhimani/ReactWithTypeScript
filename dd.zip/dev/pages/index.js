function Home() {
  return (
    <div>
      <p>Welcome to Next.js!</p>
    </div>
  );
}

export default Home;

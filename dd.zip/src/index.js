import React from "react";

import 'bootstrap/dist/css/bootstrap.min.css';
// import "./style.css"
class CheckBox extends React.Component {
  render() {
    const { checked, onChange, label } = this.props;
    return (
      <>
        <input
          className="form-check-input"
          type="checkbox"
          checked={checked}
          onChange={onChange}
          name={label}
        />
        <label className="lab" >{label}</label>
      </>
    );
  }
}
export default CheckBox;